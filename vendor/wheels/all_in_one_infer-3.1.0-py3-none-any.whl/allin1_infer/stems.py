# Copyright (c) 2023 Taejun Kim (All-In-One original)
# Copyright (c) 2025 Bo-Yu Chen (Integration modifications)
# SPDX-License-Identifier: MIT

"""Stem input/output handling for flexible source separation.

This module provides interfaces for working with pre-separated stems,
allowing developers to use custom source separation models or skip source
separation entirely if stems are already available. It also holds the
in-memory vs. disk-based separation split: `DemucsProvider.get_stems` writes
stem wavs to disk and is used whenever byproducts must be kept or stems
already exist on disk, while `separate_in_memory` skips that write/read round
trip (~0.83s/track) by handing stem tensors straight to spectrogram
extraction. The two paths must stay numerically identical, which is what
`quantize_stem_to_madmom_mono_int16` guarantees: it reproduces, bit-for-bit,
the int16 mono array madmom's `Signal(path, num_channels=1)` would read back
from a wav written by `demucs_infer.audio.save_audio` -- if demucs-infer ever
changes `save_audio`'s defaults (clip mode, bit depth), this needs
re-verification against the real on-disk round trip.

`_run_demucs_separation` loads the user's ORIGINAL input file (whatever
format they passed in -- wav/flac/mp3/...), not demucs's own output; see
`_load_input_audio`'s docstring for the wav/flac-via-soundfile,
mp3-stays-torchaudio-only split this requires (3.1.0, mirroring
demucs-infer 4.2.2's torchaudio>=2.11 fix).

Reads: demucs_infer (pretrained.get_model, apply.apply_model, audio.save_audio)
"""

import sys
import subprocess
import torch
import torchaudio
import soundfile as sf
from pathlib import Path
from typing import List, Union, Optional, Dict, Callable, Protocol, Tuple
from abc import ABC, abstractmethod

# Import demucs-infer for source separation
from demucs_infer.pretrained import get_model
from demucs_infer.apply import apply_model
from demucs_infer.audio import save_audio, prevent_clip

import numpy as np

from .spectrogram import STEM_NAMES


class StemSeparator(Protocol):
    """Protocol for custom source separation implementations."""
    
    def separate(self, audio_path: Path, output_dir: Path, device: Union[str, torch.device]) -> Path:
        """
        Separate audio into stems.
        
        Parameters
        ----------
        audio_path : Path
            Path to the input audio file
        output_dir : Path
            Directory to save separated stems
        device : Union[str, torch.device]
            Device to use for separation
            
        Returns
        -------
        Path
            Path to directory containing separated stems (bass.wav, drums.wav, other.wav, vocals.wav)
        """
        ...


class StemProvider(ABC):
    """Abstract base class for stem providers."""
    
    @abstractmethod
    def get_stems(self, identifier: Union[Path, str], output_dir: Path) -> Path:
        """
        Get stems for a given audio identifier.
        
        Parameters
        ----------
        identifier : Union[Path, str]
            Audio file path or identifier
        output_dir : Path
            Directory to save/copy stems
            
        Returns
        -------
        Path
            Path to directory containing stems (bass.wav, drums.wav, other.wav, vocals.wav)
        """
        pass


# Extensions where soundfile's decode is empirically bit-identical to
# torchaudio's at this call site (verified: torchaudio==2.7.1+cu126 vs
# soundfile==0.13.1 -- PCM16/24/32 wav + FLAC, mono/stereo synthetic
# fixtures, plus the two real multi-minute stereo wav assets under
# assets/ -- np.array_equal exact on every file; see docs/CHANGELOG.md's
# 3.1.0 entry and demucs-infer's matching 4.2.2 fix). mp3 (and anything
# else) is deliberately excluded: the same check measured mp3 decode to
# differ by up to ~2.4e-6 per sample between torchaudio (ffmpeg-backed)
# and soundfile (libmpg123-backed) -- consistent with demucs-infer's own
# ~7e-7 finding on a different mp3 file -- so lossy formats never
# silently switch decoders here.
_LOSSLESS_SOUNDFILE_EXTS = {'.wav', '.flac'}


def _load_input_audio(audio_path: Union[Path, str]) -> Tuple[torch.Tensor, int]:
    """Load the user's ORIGINAL input audio file (arbitrary format --
    wav/flac/mp3/whatever librosa/torchaudio can decode -- NOT demucs's own
    stem output) into a [channels, samples] float32 tensor, matching
    torchaudio.load's convention.

    wav/flac go through soundfile first (bit-identical to torchaudio here,
    see `_LOSSLESS_SOUNDFILE_EXTS`), so a fresh install keeps working on
    torchaudio>=2.11 without the separate torchcodec package. Every other
    format -- mp3 in particular, since it's a documented, first-class input
    format for this package (see README's "Concerning MP3 Files") -- stays
    on torchaudio only: soundfile's mp3 decode is not proven to match it, so
    it must never be a silent fallback. If torchaudio itself can't decode
    (torchaudio>=2.11 without torchcodec), a clear actionable error is
    raised instead.
    """
    path = Path(audio_path)
    if path.suffix.lower() in _LOSSLESS_SOUNDFILE_EXTS:
        data, sr = sf.read(str(path), dtype='float32', always_2d=True)
        return torch.from_numpy(data.T).contiguous(), sr

    try:
        return torchaudio.load(str(path))
    except Exception as err:
        raise RuntimeError(
            f"Failed to load '{path}' via torchaudio: {err}. torchaudio>=2.11 "
            "dropped its bundled decoders (mp3 included) in favor of the "
            "separate torchcodec package. This format is not silently routed "
            "through soundfile instead (its mp3 decode isn't proven "
            "bit-identical to torchaudio's) -- install torchcodec "
            "(`pip install torchcodec`), or convert the file to wav/flac, "
            "which this package decodes via soundfile without torchcodec."
        ) from err


def _run_demucs_separation(
    model,
    audio_path: Union[Path, str],
    device: Union[str, torch.device],
    overlap: float,
    fp16: bool,
    progress_callback: Optional[Callable[[str, float], None]] = None,
) -> Tuple[torch.Tensor, int]:
    """Shared load -> force-stereo -> apply_model -> to-CPU sequence used by
    both DemucsProvider.get_stems (writes stems to disk) and
    separate_in_memory (keeps stems as in-memory arrays), so the two paths
    can't numerically drift apart. Returns (sources, sr) with the batch
    dimension already squeezed out and sources moved to CPU.
    """
    if progress_callback:
        progress_callback("Loading audio file", 0.2)

    wav, sr = _load_input_audio(audio_path)

    # Ensure stereo (demucs requires 2 channels)
    if wav.shape[0] == 1:
        wav = wav.repeat(2, 1)
    elif wav.shape[0] > 2:
        wav = wav[:2]

    # Add batch dimension and move to device
    wav_batch = wav.unsqueeze(0).to(device)

    if progress_callback:
        progress_callback("Separating audio sources", 0.3)

    with torch.no_grad():
        if fp16 and 'cuda' in str(device):
            with torch.autocast('cuda', dtype=torch.float16):
                sources = apply_model(
                    model, wav_batch, device=device,
                    progress=bool(progress_callback), overlap=overlap,
                )
        else:
            sources = apply_model(
                model, wav_batch, device=device,
                progress=bool(progress_callback), overlap=overlap,
            )

    # Move to CPU immediately to free GPU memory, remove batch dimension
    sources = sources.cpu().squeeze(0)

    del wav_batch
    if device == 'cuda' and torch.cuda.is_available():
        torch.cuda.empty_cache()

    return sources, sr


class DemucsProvider(StemProvider):
    """Default stem provider using integrated separation module with model caching."""

    def __init__(
        self,
        model_name: str = 'htdemucs',
        device: Union[str, torch.device] = 'cuda',
        demucs_overlap: float = 0.25,
        demucs_fp16: bool = False,
    ):
        self.model_name = model_name
        self.device = device
        # EXPERIMENTAL, accuracy-affecting knobs -- defaults reproduce prior
        # behavior exactly (0.25 is demucs' own apply_model default, fp16=False
        # keeps separation in fp32). See profiling notes: non-default overlap
        # and fp16 autocast can shift segment boundaries slightly.
        self.demucs_overlap = demucs_overlap
        self.demucs_fp16 = demucs_fp16
        self._model = None  # Cache for loaded model

    @property
    def model(self):
        """Lazy-load and cache the separation model."""
        if self._model is None:
            self._model = get_model(self.model_name)
            self._model = self._model.to(self.device)
            self._model.eval()  # Freeze batch norm, dropout for inference
        return self._model

    def clear_model_cache(self):
        """Clear cached model to free memory."""
        if self._model is not None:
            del self._model
            self._model = None
            if self.device == 'cuda' and torch.cuda.is_available():
                torch.cuda.empty_cache()

    def get_stems(
        self,
        identifier: Union[Path, str],
        output_dir: Path,
        progress_callback: Optional[Callable[[str, float], None]] = None
    ) -> Path:
        """
        Use integrated separation module to separate audio into stems.

        Parameters
        ----------
        identifier : Union[Path, str]
            Path to audio file to separate
        output_dir : Path
            Directory to save separated stems
        progress_callback : Optional[Callable[[str, float], None]]
            Optional callback function(message: str, progress: float [0-1])

        Returns
        -------
        Path
            Directory containing separated stems
        """
        audio_path = Path(identifier)
        stems_dir = output_dir / self.model_name / audio_path.stem

        # Check if stems already exist
        required_stems = [f'{name}.wav' for name in STEM_NAMES]
        if all((stems_dir / stem).exists() for stem in required_stems):
            if progress_callback:
                progress_callback("Stems already exist, skipping separation", 1.0)
            return stems_dir

        # Create output directory
        stems_dir.mkdir(parents=True, exist_ok=True)

        # Load model (cached after first call)
        if progress_callback:
            progress_callback("Loading separation model", 0.1)

        model = self.model  # Uses cached model if available

        sources, sr = _run_demucs_separation(
            model, audio_path, self.device, self.demucs_overlap, self.demucs_fp16,
            progress_callback=progress_callback,
        )

        # Save stems
        if progress_callback:
            progress_callback("Saving separated stems", 0.8)

        source_names = model.sources
        for i, source_name in enumerate(source_names):
            stem_path = stems_dir / f'{source_name}.wav'
            save_audio(sources[i], str(stem_path), sr)

        # Clean up CPU memory
        del sources

        if progress_callback:
            progress_callback("Separation complete", 1.0)

        return stems_dir


def quantize_stem_to_madmom_mono_int16(wav: torch.Tensor) -> np.ndarray:
    """Reproduce, bit-for-bit, the int16 mono array that madmom's
    ``Signal(path, num_channels=1)`` reads back from a stem wav file written
    by ``demucs_infer.audio.save_audio(wav, path, sr)`` with its defaults
    (``clip='rescale'``, PCM_S 16-bit). Lets the in-memory pipeline skip the
    wav write/read round trip while staying numerically identical to it.

    wav : [channels, samples] float32 tensor (one row of demucs `sources`).

    Verified empirically against the real on-disk round trip (see the perf
    validation script); if demucs-infer ever changes save_audio's defaults
    (clip mode, bit depth) this needs to be re-verified against it.
    """
    wav = prevent_clip(wav, mode='rescale')
    # PCM_S16 quantization -- matches torchaudio's soundfile backend exactly
    # (round-half-to-even via torch.round, then clamp to int16 range).
    quantized = (wav.clamp(-1, 1) * 32768).round().clamp(-32768, 32767).to(torch.int16)
    arr = quantized.cpu().numpy().T  # [samples, channels], scipy.io.wavfile's convention
    # madmom's remix() to mono for integer dtypes: mean over the channel axis
    # in float64, then cast back to int16 -- numpy's float->int astype
    # truncates toward zero, it does not round.
    return np.mean(arr, axis=-1).astype(np.int16)


def separate_in_memory(
    paths: List[Path],
    demix_dir: Path,
    device: Union[str, torch.device] = 'cuda',
    demucs_overlap: float = 0.25,
    demucs_fp16: bool = False,
):
    """Fresh-run fast path for the default DemucsProvider: separates audio
    directly into in-memory mono stem arrays, skipping the stem wav
    write/read round trip (~0.83s/track).

    Tracks whose stems already exist on disk are left untouched and reported
    back as `cached_paths` -- callers must run those through the ordinary
    get_stems()/extract_spectrograms() path so existing keep_byproducts /
    resumed-run caching semantics are preserved exactly.

    Returns
    -------
    cached_paths : List[Path]
        Subset of `paths` whose stems are already cached on disk.
    stems_dirs : Dict[Path, Path]
        For every path in `paths` (cached or fresh): the stems directory that
        holds/would hold its stem wavs, mirroring DemucsProvider.get_stems()'s
        naming, for bookkeeping/cleanup.
    arrays_by_path : Dict[Path, Dict[str, np.ndarray]]
        For the freshly-separated paths only: {'bass': arr, 'drums': arr,
        'other': arr, 'vocals': arr} mono int16 arrays.
    sr_by_path : Dict[Path, int]
        For the freshly-separated paths only: each track's native sample
        rate. Per-track because the disk path preserves each file's own rate
        (torchaudio.load -> save_audio(..., sr) with no resampling), so a
        mixed-rate batch must carry a rate per file, not one shared value.
    """
    provider = DemucsProvider(device=device)
    required_stems = [f'{name}.wav' for name in STEM_NAMES]

    cached_paths = []
    stems_dirs = {}
    arrays_by_path = {}
    sr_by_path = {}

    for path in paths:
        stems_dir = demix_dir / provider.model_name / Path(path).stem
        stems_dirs[path] = stems_dir
        if all((stems_dir / stem).exists() for stem in required_stems):
            cached_paths.append(path)
            continue

        sources, sr = _run_demucs_separation(
            provider.model, path, device, demucs_overlap, demucs_fp16,
        )

        arrays_by_path[path] = {
            name: quantize_stem_to_madmom_mono_int16(sources[i])
            for i, name in enumerate(provider.model.sources)
        }
        sr_by_path[path] = sr

    return cached_paths, stems_dirs, arrays_by_path, sr_by_path


class PrecomputedStemProvider(StemProvider):
    """Provider for pre-computed stems."""
    
    def __init__(self, stems_mapping: Optional[Dict[str, Path]] = None):
        """
        Initialize with optional stems mapping.
        
        Parameters
        ----------
        stems_mapping : Optional[Dict[str, Path]]
            Mapping from audio identifiers to stem directories
        """
        self.stems_mapping = stems_mapping or {}
    
    def add_stems(self, identifier: str, stems_dir: Path):
        """Add stems for a given identifier."""
        self.stems_mapping[identifier] = Path(stems_dir)
    
    def get_stems(self, identifier: Union[Path, str], output_dir: Path) -> Path:
        """Get pre-computed stems."""
        key = str(identifier)
        if key not in self.stems_mapping:
            raise ValueError(f"No stems found for identifier: {key}")
        
        source_dir = self.stems_mapping[key]
        target_dir = output_dir / Path(identifier).stem
        
        # Ensure target directory exists
        target_dir.mkdir(parents=True, exist_ok=True)
        
        # Copy or link stems if needed
        required_stems = [f'{name}.wav' for name in STEM_NAMES]
        for stem in required_stems:
            source_stem = source_dir / stem
            target_stem = target_dir / stem
            
            if not target_stem.exists() and source_stem.exists():
                # Create symbolic link to avoid copying large files
                try:
                    target_stem.symlink_to(source_stem.resolve())
                except OSError:
                    # Fallback to copying if symlink fails
                    import shutil
                    shutil.copy2(source_stem, target_stem)
        
        return target_dir


class CustomSeparatorProvider(StemProvider):
    """Provider that uses a custom separation function."""
    
    def __init__(self, separator_fn: StemSeparator):
        """
        Initialize with custom separator function.
        
        Parameters
        ----------
        separator_fn : StemSeparator
            Custom function that implements the StemSeparator protocol
        """
        self.separator_fn = separator_fn
    
    def get_stems(self, identifier: Union[Path, str], output_dir: Path) -> Path:
        """Use custom separator to generate stems."""
        audio_path = Path(identifier)
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        return self.separator_fn.separate(audio_path, output_dir, device)


def get_stems(
    paths: List[Path],
    stems_dir: Path,
    stem_provider: Optional[StemProvider] = None,
    device: Union[str, torch.device] = 'cuda',
    demucs_overlap: float = 0.25,
    demucs_fp16: bool = False,
) -> List[Path]:
    """
    Get stems for audio files using specified provider.

    Parameters
    ----------
    paths : List[Path]
        List of audio file paths
    stems_dir : Path
        Directory to store stems
    stem_provider : Optional[StemProvider]
        Stem provider to use. If None, uses default DemucsProvider
    device : Union[str, torch.device]
        Device to use for separation
    demucs_overlap : float
        EXPERIMENTAL, accuracy-affecting. Only used when stem_provider is None
        (default DemucsProvider). See DemucsProvider.__init__.
    demucs_fp16 : bool
        EXPERIMENTAL, accuracy-affecting. Only used when stem_provider is None
        (default DemucsProvider). See DemucsProvider.__init__.

    Returns
    -------
    List[Path]
        List of paths to directories containing stems
    """
    if stem_provider is None:
        stem_provider = DemucsProvider(device=device, demucs_overlap=demucs_overlap, demucs_fp16=demucs_fp16)
    
    stem_paths = []
    todos = []
    
    for path in paths:
        try:
            stem_path = stem_provider.get_stems(path, stems_dir)
            stem_paths.append(stem_path)
        except Exception as e:
            print(f"Warning: Failed to get stems for {path}: {e}")
            todos.append(path)
    
    if todos:
        print(f"=> Found {len(paths) - len(todos)} tracks with stems ready, {len(todos)} failed.")
        # Could implement fallback logic here if needed
    else:
        print(f"=> All {len(paths)} tracks have stems ready.")
    
    return stem_paths